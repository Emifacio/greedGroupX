 #pragma once

void menuEstadisticas();
void cargarPuntos(int ranking[], std::string nombres[]);
void mostrarRanking(int rankingp[]);
void cargarPuntosAutomaticos(int ranking[]);
void ordenar(int ranking[], std::string nombres[], int cant);
void asignarNombresAleatorios(int ranking[], std::string nombres[]);
void agregarNombreYPuntaje(int ranking[], std::string nombres[]);
