# pragma once


void tiradaBloqueadores(int v[], int t);
int tirarDadito();
void tiradaDeDados(int vD[], int tam);
bool dadosIguales(int vD[], int t);
int dadosNuevos(int vD[],int t,int vB[2]);
void mostrarDados(int vD[], int tam);
int sumarDados(int vD[], int t);

