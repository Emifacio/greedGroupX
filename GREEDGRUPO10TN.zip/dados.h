#pragma once

void dibujarCuadradoColor(int columna, int fila);
void dibujarCuadrado(int columna, int fila);
void dibujarDado(int numero, int columna, int fila);
void dibujarDadoColor(int numero, int columna, int fila ,int color=15, int colorPoint=0);
void dibujarPuntosColor(int numero, int columna, int fila);
void dibujarSombra( int columna, int fila);
void dibujarPuntos(int numero, int columna, int fila);
int tirarDado(int columna, int fila);
void dibujarBloqueadores(int vD[]);
void dibujarDadoQuieto(int numero, int columna, int fila, int color, int colorPoint);
void dibujarBloqueadoresQuieto(int vD[]);

