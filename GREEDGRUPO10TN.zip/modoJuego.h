#pragma once
#include<iostream>
#include<ctime>
#include "funciones.h"
#include "rlutil.h"
//#include "ranking.h"
#include "carteles.h"


void modoDosJugadores() ;
void modoUnJugador();
void codigoRonda(std::string jugador, int ronda, int aPt, int aP[]);
